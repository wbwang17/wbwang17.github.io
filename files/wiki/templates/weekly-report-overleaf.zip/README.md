# Weekly Research Report Template

This project is adapted from Elsevier's single-column `elsarticle` preprint style and is designed for bilingual Chinese/English weekly research reports.

## Compile on Overleaf

1. Upload the ZIP file as a new Overleaf project.
2. Keep `main.tex` as the Main document. It initially points to `main_template.tex`.
3. Use XeLaTeX as the compiler. The included `latexmkrc` normally selects it automatically.
4. Compile once to confirm that the template and example image display correctly.

## Create a dated weekly report

For a report submitted on 2026-09-14:

1. Copy `main_template.tex` to `main_20260914.tex`.
2. Copy `secs/template/` to `secs/20260914/`.
3. Copy `figures/template/` to `figures/20260914/`, then replace or delete the example image.
4. In `main_20260914.tex`, change `ReportKey` to `20260914` and update the report period and submission date.
5. Change the single `\\input` line in `main.tex` to `\\input{main_20260914.tex}`.

For later weeks, either copy the template again or copy the previous dated report and replace its content. Keep `report-settings.tex` and `main.bib` shared across all weeks. The plan for last week should be copied from the previous report's plan for this week, so that progress can be checked item by item.
