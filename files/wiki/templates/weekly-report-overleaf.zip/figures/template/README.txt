This directory contains the example figure used by the template report.
Before writing a dated report, copy this directory to figures/YYYYMMDD/.

Recommended formats: PDF for vector graphics; PNG or JPG for raster images.
Replace weekly-report-preview.png with your own figures when writing the report.
Use clear file names such as baseline-comparison.pdf or loss-curve.png.
In a section file, include the image by file name only, for example:

\includegraphics[width=0.82\linewidth]{loss-curve.png}
